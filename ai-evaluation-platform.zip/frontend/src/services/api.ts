const API=import.meta.env.VITE_API_URL||'http://localhost:8000';
export async function api<T>(path:string, options:RequestInit={}):Promise<T>{const token=localStorage.getItem('token');const res=await fetch(`${API}${path}`,{...options,headers:{'Content-Type':'application/json',...(token?{Authorization:`Bearer ${token}`}:{ }),...(options.headers||{})}});if(!res.ok)throw new Error((await res.json()).detail||'Request failed');return res.json();}
export const getStats=()=>api<any>('/api/v1/stats');
