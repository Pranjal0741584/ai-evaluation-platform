export type Stats={total_models:number;total_datasets:number;evaluations:number;successful_evaluations:number;failed_evaluations:number};
