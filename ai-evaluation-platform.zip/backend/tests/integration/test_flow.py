from tests.conftest import client, reset_db

def setup_function(): reset_db()
def test_end_to_end():
    r=client.post('/api/v1/auth/register',json={'email':'test@example.com','password':'password123'}); assert r.status_code==201
    token=r.json()['access_token']; h={'Authorization':f'Bearer {token}'}
    r=client.post('/api/v1/models',headers=h,json={'name':'demo','version':'1','provider':'mock','model_type':'classifier'}); assert r.status_code==201; mid=r.json()['id']
    r=client.post('/api/v1/datasets',headers=h,json={'name':'ds','version':'1','records':[{'input':'a','expected':'x'}]}); assert r.status_code==201; did=r.json()['id']
    r=client.post('/api/v1/evaluations',headers=h,json={'model_id':mid,'dataset_id':did}); assert r.status_code==202; eid=r.json()['id']
    r=client.post(f'/api/v1/evaluations/{eid}/run',headers=h); assert r.status_code==200; assert r.json()['status']=='COMPLETED'
    r=client.get(f'/api/v1/evaluations/{eid}/results',headers=h); assert r.status_code==200; assert 'accuracy' in r.json()
