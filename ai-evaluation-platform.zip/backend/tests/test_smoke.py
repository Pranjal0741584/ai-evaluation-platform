from tests.conftest import client
def test_health(): assert client.get('/health').json()=={'status':'ok'}
def test_auth_required(): assert client.get('/api/v1/models').status_code==401
