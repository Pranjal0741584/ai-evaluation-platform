from app.services.evaluator import MockModelEvaluator

def test_mock_evaluator_is_deterministic():
    e=MockModelEvaluator(); records=[{"input":"a","expected":"x"}]
    a=e.evaluate({"name":"m","version":"1"},records,{})
    b=e.evaluate({"name":"m","version":"1"},records,{})
    assert a == b
    assert 0 <= a.accuracy <= 1

def test_empty_dataset_fails():
    try: MockModelEvaluator().evaluate({"name":"m","version":"1"},[],{})
    except ValueError as exc: assert "empty" in str(exc).lower()
    else: assert False
