import os
os.environ["DATABASE_URL"] = "sqlite:///./test.db"
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.main import app
from app.db.session import Base, get_db

engine=create_engine("sqlite:///./test.db",connect_args={"check_same_thread":False})
TestingSession=sessionmaker(bind=engine,autoflush=False,autocommit=False)
Base.metadata.create_all(engine)

def override_db():
    db=TestingSession()
    try: yield db
    finally: db.close()
app.dependency_overrides[get_db]=override_db
client=TestClient(app)

def reset_db(): Base.metadata.drop_all(engine); Base.metadata.create_all(engine)
