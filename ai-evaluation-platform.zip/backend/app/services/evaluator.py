from dataclasses import dataclass
import hashlib
import time

@dataclass(frozen=True)
class EvaluationMetrics:
    accuracy: float; precision: float; recall: float; f1_score: float; latency_ms: float; error_rate: float

class ModelEvaluator:
    def evaluate(self, model: dict, records: list[dict], configuration: dict) -> EvaluationMetrics:
        raise NotImplementedError

class MockModelEvaluator(ModelEvaluator):
    """Deterministic evaluator; replaceable by a real provider adapter later."""
    def evaluate(self, model: dict, records: list[dict], configuration: dict) -> EvaluationMetrics:
        if not records:
            raise ValueError("Dataset cannot be empty")
        seed = hashlib.sha256(f"{model['name']}:{model['version']}:{len(records)}:{configuration}".encode()).hexdigest()
        base = int(seed[:8], 16) / 0xFFFFFFFF
        accuracy = round(0.75 + 0.2 * base, 4)
        precision = round(max(0.0, accuracy - 0.03), 4)
        recall = round(max(0.0, accuracy - 0.02), 4)
        f1 = round(2 * precision * recall / (precision + recall), 4)
        latency = round(20 + (int(seed[8:12], 16) % 800) / 10, 2)
        return EvaluationMetrics(accuracy, precision, recall, f1, latency, round(1 - accuracy, 4))
