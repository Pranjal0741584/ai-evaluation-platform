from sqlalchemy.orm import Session
from app.models import Evaluation, EvaluationResult, Job, Model, Dataset
from app.services.evaluator import ModelEvaluator

def run_evaluation(db: Session, evaluation_id: int, evaluator: ModelEvaluator) -> None:
    evaluation = db.get(Evaluation, evaluation_id)
    if not evaluation: raise ValueError("Evaluation not found")
    model = db.get(Model, evaluation.model_id); dataset = db.get(Dataset, evaluation.dataset_id)
    if not model or not dataset: raise ValueError("Model or dataset not found")
    evaluation.status = "RUNNING"
    db.commit()
    try:
        metrics = evaluator.evaluate({"name": model.name, "version": model.version}, dataset.records, evaluation.configuration)
        db.add(EvaluationResult(evaluation_id=evaluation.id, **metrics.__dict__))
        evaluation.status = "COMPLETED"
    except Exception as exc:
        evaluation.status = "FAILED"; evaluation.error_message = str(exc)
        raise
    finally:
        db.commit()
