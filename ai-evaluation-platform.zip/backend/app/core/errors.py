from fastapi import Request
from fastapi.responses import JSONResponse
from sqlalchemy.exc import IntegrityError
from app.core.logging import logger

def install_exception_handlers(app):
    @app.exception_handler(IntegrityError)
    async def integrity_handler(request: Request, exc: IntegrityError):
        logger.warning("integrity_error", extra={"path": request.url.path})
        return JSONResponse(status_code=409, content={"error": {"code": "CONFLICT", "message": "Resource conflicts with existing data."}})
    @app.exception_handler(Exception)
    async def unhandled_handler(request: Request, exc: Exception):
        logger.exception("unhandled_error", extra={"path": request.url.path})
        return JSONResponse(status_code=500, content={"error": {"code": "INTERNAL_ERROR", "message": "Internal server error."}})
