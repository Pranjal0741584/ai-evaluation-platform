import time
from uuid import uuid4
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes import router
from app.core.config import settings
from app.core.errors import install_exception_handlers
from app.core.logging import logger
from app.db.session import Base, engine
import app.models  # noqa: F401

app = FastAPI(title=settings.app_name, version="0.1.0", docs_url="/docs", openapi_url="/openapi.json")
app.add_middleware(CORSMiddleware, allow_origins=[x.strip() for x in settings.cors_origins.split(",")], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
install_exception_handlers(app)
@app.middleware("http")
async def request_context(request: Request, call_next):
    request_id=str(uuid4()); start=time.perf_counter(); response=await call_next(request); response.headers["X-Request-ID"]=request_id
    logger.info("request", extra={"request_id":request_id,"endpoint":request.url.path,"response_time_ms":round((time.perf_counter()-start)*1000,2)})
    return response
@app.on_event("startup")
def startup(): Base.metadata.create_all(bind=engine)
@app.get("/health")
def health(): return {"status":"ok"}
@app.get("/ready")
def ready():
    try:
        with engine.connect() as conn: conn.exec_driver_sql("SELECT 1")
        return {"status":"ready"}
    except Exception: return {"status":"not_ready"}
app.include_router(router)
