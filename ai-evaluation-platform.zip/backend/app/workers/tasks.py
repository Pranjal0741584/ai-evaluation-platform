try:
    from app.workers.celery_app import celery_app
    @celery_app.task(bind=True, autoretry_for=(Exception,), retry_backoff=True, max_retries=3)
    def process_evaluation(self, evaluation_id: int):
        from app.db.session import SessionLocal
        from app.services.evaluator import MockModelEvaluator
        from app.services.evaluation_service import run_evaluation
        with SessionLocal() as db: run_evaluation(db, evaluation_id, MockModelEvaluator())
except ModuleNotFoundError:
    class _UnavailableTask:
        def delay(self, evaluation_id: int):
            raise RuntimeError("Celery is unavailable; use the synchronous test runner or install backend dependencies.")
    process_evaluation = _UnavailableTask()
