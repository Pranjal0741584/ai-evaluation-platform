from celery import Celery
from app.core.config import settings
celery_app = Celery("ai_evaluation", broker=settings.redis_url, backend=settings.redis_url)
celery_app.conf.update(task_acks_late=True, task_reject_on_worker_lost=True, task_default_retry_delay=5, task_max_retries=3)
