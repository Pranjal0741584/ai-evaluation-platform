from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field

class UserCreate(BaseModel):
    email: str = Field(min_length=5, max_length=255)
    password: str = Field(min_length=8, max_length=128)
class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
class ModelCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    version: str = Field(min_length=1, max_length=50)
    description: str | None = None
    provider: str = Field(min_length=1, max_length=100)
    model_type: str = Field(min_length=1, max_length=100)
class ModelUpdate(BaseModel):
    description: str | None = None
    status: str | None = Field(default=None, min_length=1, max_length=30)
class ModelOut(ModelCreate):
    id: int; status: str; created_at: datetime; updated_at: datetime
    model_config = ConfigDict(from_attributes=True)
class DatasetCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    description: str | None = None
    version: str = Field(min_length=1, max_length=50)
    records: list[dict] = Field(min_length=1, max_length=10000)
class DatasetOut(DatasetCreate):
    id: int; created_at: datetime
    model_config = ConfigDict(from_attributes=True)
class EvaluationCreate(BaseModel):
    model_id: int = Field(gt=0)
    dataset_id: int = Field(gt=0)
    configuration: dict = Field(default_factory=dict)
class EvaluationOut(BaseModel):
    id: int; model_id: int; dataset_id: int; status: str; error_message: str | None
    created_at: datetime; updated_at: datetime
    model_config = ConfigDict(from_attributes=True)
class ResultOut(BaseModel):
    accuracy: float; precision: float; recall: float; f1_score: float; latency_ms: float; error_rate: float
    model_config = ConfigDict(from_attributes=True)
