from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func
from sqlalchemy.orm import Session
from app.api.deps import current_user, db_dep
from app.core.security import create_token, hash_password, verify_password
from app.models import Dataset, Evaluation, EvaluationResult, Job, Model, User
from app.schemas.common import *
from app.services.evaluator import MockModelEvaluator
from app.services.evaluation_service import run_evaluation
from app.workers.tasks import process_evaluation

router = APIRouter(prefix="/api/v1")

def require_user(user=Depends(current_user)): return user

@router.post("/auth/register", response_model=Token, status_code=201)
def register(payload: UserCreate, db: Session = Depends(db_dep)):
    if db.query(User).filter(User.email == payload.email).first(): raise HTTPException(409, "Email already registered")
    db.add(User(email=payload.email, password_hash=hash_password(payload.password))); db.commit()
    return {"access_token": create_token(payload.email), "token_type": "bearer"}

@router.post("/auth/login", response_model=Token)
def login(payload: UserCreate, db: Session = Depends(db_dep)):
    user = db.query(User).filter(User.email == payload.email).first()
    if not user or not verify_password(payload.password, user.password_hash): raise HTTPException(401, "Invalid credentials")
    return {"access_token": create_token(user.email), "token_type": "bearer"}

@router.post("/models", response_model=ModelOut, status_code=201)
def create_model(payload: ModelCreate, db: Session = Depends(db_dep), _=Depends(require_user)):
    obj = Model(**payload.model_dump()); db.add(obj); db.commit(); db.refresh(obj); return obj
@router.get("/models", response_model=list[ModelOut])
def list_models(page: int=Query(1, ge=1), page_size: int=Query(20, ge=1, le=100), sort: str="created_at", db: Session=Depends(db_dep), _=Depends(require_user)):
    column = getattr(Model, sort, Model.created_at); return db.query(Model).order_by(column.desc()).offset((page-1)*page_size).limit(page_size).all()
@router.get("/models/{model_id}", response_model=ModelOut)
def get_model(model_id: int, db: Session=Depends(db_dep), _=Depends(require_user)):
    obj=db.get(Model, model_id)
    if not obj: raise HTTPException(404, "Model not found")
    return obj
@router.put("/models/{model_id}", response_model=ModelOut)
def update_model(model_id:int,payload:ModelUpdate,db:Session=Depends(db_dep),_=Depends(require_user)):
    obj=db.get(Model,model_id)
    if not obj: raise HTTPException(404,"Model not found")
    for k,v in payload.model_dump(exclude_unset=True).items(): setattr(obj,k,v)
    db.commit(); db.refresh(obj); return obj
@router.delete("/models/{model_id}",status_code=204)
def delete_model(model_id:int,db:Session=Depends(db_dep),_=Depends(require_user)):
    obj=db.get(Model,model_id)
    if not obj: raise HTTPException(404,"Model not found")
    db.delete(obj); db.commit()

@router.post("/datasets", response_model=DatasetOut, status_code=201)
def create_dataset(payload:DatasetCreate,db:Session=Depends(db_dep),_=Depends(require_user)):
    obj=Dataset(**payload.model_dump()); db.add(obj); db.commit(); db.refresh(obj); return obj
@router.get("/datasets", response_model=list[DatasetOut])
def list_datasets(page:int=Query(1,ge=1),page_size:int=Query(20,ge=1,le=100),db:Session=Depends(db_dep),_=Depends(require_user)):
    return db.query(Dataset).order_by(Dataset.created_at.desc()).offset((page-1)*page_size).limit(page_size).all()
@router.get("/datasets/{dataset_id}",response_model=DatasetOut)
def get_dataset(dataset_id:int,db:Session=Depends(db_dep),_=Depends(require_user)):
    obj=db.get(Dataset,dataset_id)
    if not obj: raise HTTPException(404,"Dataset not found")
    return obj
@router.delete("/datasets/{dataset_id}",status_code=204)
def delete_dataset(dataset_id:int,db:Session=Depends(db_dep),_=Depends(require_user)):
    obj=db.get(Dataset,dataset_id)
    if not obj: raise HTTPException(404,"Dataset not found")
    db.delete(obj); db.commit()

@router.post("/evaluations",response_model=EvaluationOut,status_code=202)
def create_evaluation(payload:EvaluationCreate,db:Session=Depends(db_dep),_=Depends(require_user)):
    if not db.get(Model,payload.model_id): raise HTTPException(404,"Model not found")
    if not db.get(Dataset,payload.dataset_id): raise HTTPException(404,"Dataset not found")
    obj=Evaluation(**payload.model_dump()); db.add(obj); db.flush(); db.add(Job(evaluation_id=obj.id)); db.commit(); db.refresh(obj)
    try: process_evaluation.delay(obj.id)
    except Exception: pass
    return obj
@router.get("/evaluations",response_model=list[EvaluationOut])
def list_evaluations(db:Session=Depends(db_dep),_=Depends(require_user)):
    return db.query(Evaluation).order_by(Evaluation.created_at.desc()).limit(100).all()
@router.get("/evaluations/{evaluation_id}",response_model=EvaluationOut)
def get_evaluation(evaluation_id:int,db:Session=Depends(db_dep),_=Depends(require_user)):
    obj=db.get(Evaluation,evaluation_id)
    if not obj: raise HTTPException(404,"Evaluation not found")
    return obj
@router.get("/evaluations/{evaluation_id}/results",response_model=ResultOut)
def get_results(evaluation_id:int,db:Session=Depends(db_dep),_=Depends(require_user)):
    obj=db.query(EvaluationResult).filter(EvaluationResult.evaluation_id==evaluation_id).first()
    if not obj: raise HTTPException(404,"Evaluation results not available")
    return obj
@router.post("/evaluations/{evaluation_id}/run",response_model=EvaluationOut)
def run_now(evaluation_id:int,db:Session=Depends(db_dep),_=Depends(require_user)):
    if not db.get(Evaluation,evaluation_id): raise HTTPException(404,"Evaluation not found")
    try: run_evaluation(db,evaluation_id,MockModelEvaluator())
    except Exception: pass
    obj=db.get(Evaluation,evaluation_id); return obj

@router.get("/stats")
def stats(db:Session=Depends(db_dep),_=Depends(require_user)):
    return {"total_models":db.query(func.count(Model.id)).scalar(),"total_datasets":db.query(func.count(Dataset.id)).scalar(),"evaluations":db.query(func.count(Evaluation.id)).scalar(),"successful_evaluations":db.query(func.count(Evaluation.id)).filter(Evaluation.status=="COMPLETED").scalar(),"failed_evaluations":db.query(func.count(Evaluation.id)).filter(Evaluation.status=="FAILED").scalar()}
