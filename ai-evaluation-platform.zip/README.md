# AI Model Evaluation & Deployment Platform

A production-minded portfolio monorepo demonstrating FastAPI, PostgreSQL, Redis/Celery, React/TypeScript, testing, Docker and CI/CD.

## Architecture

```mermaid
flowchart LR
  UI[React + TypeScript] --> API[FastAPI REST API]
  API --> DB[(PostgreSQL)]
  API --> Q[(Redis)]
  Q --> W[Celery Worker]
  W --> E[Evaluation Engine]
  E --> DB
```

## Run with Docker

```bash
cp .env.example .env
docker compose up --build
```

- Frontend: http://localhost:5173
- Backend: http://localhost:8000
- Swagger: http://localhost:8000/docs
- Health: http://localhost:8000/health
- Readiness: http://localhost:8000/ready

## Local backend tests

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pytest -q
ruff check app tests
```

The default local test configuration uses SQLite so tests do not require paid or hosted services. Production configuration uses PostgreSQL and Redis through environment variables.

## Evaluation flow

Register/login -> create model -> create dataset -> create evaluation -> enqueue Celery job -> worker runs deterministic mock evaluator -> persist metrics -> retrieve results.

A synchronous `/run` endpoint is included to make the core evaluation flow testable without Redis; production requests use the background task path.
