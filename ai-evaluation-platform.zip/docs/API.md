# API

Authentication: `POST /api/v1/auth/register`, `POST /api/v1/auth/login`.

Protected resources use `Authorization: Bearer <JWT>`.

Models: `POST/GET /api/v1/models`, `GET/PUT/DELETE /api/v1/models/{id}`.

Datasets: `POST/GET /api/v1/datasets`, `GET/DELETE /api/v1/datasets/{id}`.

Evaluations: `POST/GET /api/v1/evaluations`, `GET /api/v1/evaluations/{id}`, `GET /api/v1/evaluations/{id}/results`.

Operational: `GET /health`, `GET /ready`, `GET /api/v1/stats`.
