# Architecture

The system is a modular monorepo. FastAPI owns HTTP contracts and authentication. SQLAlchemy isolates persistence. Redis/Celery handles long-running evaluations. `ModelEvaluator` is an abstraction so `MockModelEvaluator` can later be replaced by an LLM/provider adapter.

## Data flow

```mermaid
sequenceDiagram
  participant C as Client
  participant A as FastAPI
  participant R as Redis
  participant W as Celery Worker
  participant D as PostgreSQL
  C->>A: POST evaluation
  A->>D: create PENDING evaluation/job
  A->>R: enqueue task
  A-->>C: 202 + evaluation id
  R->>W: task
  W->>D: RUNNING
  W->>W: deterministic evaluation
  W->>D: result + COMPLETED
```
