# Architecture Decisions

## Deterministic mock evaluator
External AI providers are intentionally avoided for local reproducibility. The evaluator interface allows a provider adapter to be added later.

## Celery + Redis
Evaluation is asynchronous because real model evaluation can be long-running. Redis provides a lightweight broker/backend for a portfolio project.

## SQLite test database
Tests use SQLite to remain runnable in environments without PostgreSQL. Production uses PostgreSQL through `DATABASE_URL`.
