# Security

- Passwords are hashed with Argon2 via `pwdlib`.
- JWTs are signed with an environment-provided secret.
- Protected APIs require bearer authentication.
- Pydantic validates request payloads.
- SQLAlchemy ORM avoids string-built SQL queries.
- CORS origins are configurable.
- Errors return safe messages rather than stack traces.
- `.env` is excluded from packaging; `.env.example` contains placeholders only.
