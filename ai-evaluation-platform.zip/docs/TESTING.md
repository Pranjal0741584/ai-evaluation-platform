# Testing

Unit tests cover deterministic evaluation and validation/error behavior. Integration tests exercise registration, JWT authentication, model/dataset CRUD and the evaluation result flow. The CI pipeline also builds both Docker images.

Do not report passing counts unless the commands have actually been executed; see `TEST_REPORT.md` for this environment's observed results.
