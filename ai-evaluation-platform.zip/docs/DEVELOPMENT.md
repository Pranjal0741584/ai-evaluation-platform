# Development

Use Python 3.12+ and Node 22+. Copy `.env.example` to `.env` for container development. Keep secrets out of Git. Backend packages are pinned for reproducible local setup.

For schema changes, create and apply Alembic migrations. Keep API, service and persistence responsibilities separate.
